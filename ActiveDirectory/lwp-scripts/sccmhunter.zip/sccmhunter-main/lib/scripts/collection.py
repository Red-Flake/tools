#


class COLLECTION:
    def __init__(self):
        return
    
    def add_collection(self):
        ## create a collection with name of c_guid
        ## validate the collection was created
        ## update local DB with new collection info with validation response body
        return
    
    def del_collection(self):
        ## delete collection, user will need to provide collection ID
        ## validate the collection was deleted
        ## update local DB with deleted collection info following validation
        return
    
    def add_collection_member(self):
        ## add a device to a collection
        ## validate the collection
        return
    
    def rm_collection_member(self):
        return
    
