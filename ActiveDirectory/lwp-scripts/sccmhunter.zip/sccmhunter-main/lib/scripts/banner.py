
__version__ = '1.0.1'


def show_banner():
    banner =f'''
                                                                                          (
                                    888                         d8                         \\
 dP"Y  e88'888  e88'888 888 888 8e  888 ee  8888 8888 888 8e   d88    ,e e,  888,8,        )
C88b  d888  '8 d888  '8 888 888 88b 888 88b 8888 8888 888 88b d88888 d88 88b 888 "    ##-------->
 Y88D Y888   , Y888   , 888 888 888 888 888 Y888 888P 888 888  888   888   , 888           )
d,dP   "88,e8'  "88,e8' 888 888 888 888 888  "88 88"  888 888  888    "YeeP" 888          /
                                                                                         (
                                                                 v{__version__}                   
                                                                 @garrfoster                    
    
    
    '''
    print(banner)

def small_banner():
    banner = f'''SCCMHunter v{__version__} by @garrfoster'''

    print(banner)
